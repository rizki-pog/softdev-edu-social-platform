import React, { useEffect, useState } from 'react'
import "./Sidebar.css";
import AddIcon from '@material-ui/icons/Add';
import SidebarChannel from './SidebarChannel';
import { Avatar } from '@material-ui/core';
import logo from './logocon.png'; 
import { useSelector } from 'react-redux';
import { selectUser } from './features/userSlice';
import db, { auth } from './firebase';
import {Dropdown} from "semantic-ui-react";

function Sidebar() {
    const user = useSelector(selectUser);
    const [channels, setChannels] = useState([]);

    useEffect(() => {
        db.collection('channels').onSnapshot(snapshot => (
            setChannels(
                snapshot.docs.map(doc => ({
                id: doc.id,
                channel: doc.data(),
            }
            )))
        ))
    }, []);

    const handleAddChannel = () => {
        const channelName = prompt('Enter a forum name');
        if (channelName) {
            db.collection('channels').add({
                channelName: channelName
            });
        }
    }

    const handleAddChannel2 = () => {
        const channelName = prompt('Enter a user name');
        if (channelName) {
            db.collection('channels').add({
                channelName: channelName
            });
        }
    }

  
    return (
        <div className="sidebar">
            <div className="sidebar__top">
            <img src={logo} alt="logo"  className="logo" />
            </div>

            <div className="sidebar__channelsHeader">
                    <div className="sidebar__chanheader">
                        <h3>FORUMS</h3>
                    </div>
                        <AddIcon onClick={handleAddChannel} className="sidebar__addChannel" />
            </div>

            <div className="sidebar__channels">
                <div className="sidebar__channelsList">
                        {channels.map(({ id, channel }) => (
                            <SidebarChannel 
                            key={id}
                            id={id}
                            channelName={channel.channelName} />
                        ))}
                </div>
            </div>        

            <div className="sidebar__voipHeader">
                    <div className="sidebar__voheader">
            
                        <h3>PRIVATE CHANNEL</h3>
                    </div>
                    <AddIcon onClick={handleAddChannel2} className="sidebar__addVoip"/>
            </div>

            <div className="sidebar__voip">
                <div className="sidebar__voipList">
                </div>
            </div> 

                <div className="sidebar__profile">
                    <Avatar onClick = {() => auth.signOut()} src={user.photo}/>
                    <div className="sidebar__profileInfo">
                        <h4>{user.displayName}  </h4>
                        <p>{user.uid.substring(0,5)}</p>
                    </div>

                    <div className="sidebar__profileIcons">
                        <select>
                            <option>My Profile </option>
                            <option>Collab</option>
                            <option>Sign Out </option>
                        </select>
                    </div>
                
                </div>
            </div>
    );
}

export default Sidebar;